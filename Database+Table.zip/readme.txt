1. First create a database called scientistsdb
2. Then navigate over to the database
3. Click import in your PHPMYAdmin.
4. Import the sql below. This will create a table for you ad add 7 rows of data. Moreover you can follow the lesson where we were creating our database table step by step in the course.